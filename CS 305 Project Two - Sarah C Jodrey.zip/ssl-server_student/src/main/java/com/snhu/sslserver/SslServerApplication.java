package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//Import libraries for RestController, Mapping, Message Digest, and Algorithm Exceptions
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

/*
 * ServerController --- class to encrypt data string using SHA-256 algorithm and generate a checksum value for that data string.
 * Date: 2022-02-20
 * Author: Sarah C Jodrey
 */

//@RestController marks the ServerController class as a request handler
@RestController
class ServerController{
	//Hash function to return the checksum value for the data string containing my name
	public static String hashFunction(String data) {
		//Try catch block to throw an exception if the SHA-256 instance cannot be found
		try {
			//Create MessageDigest object specifying cipher algorithm SHA-256
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			//Pass data string to the MessageDigest object
			md.update(data.getBytes());
			//Generate hash value of the type byte from data String
			byte[] digest = md.digest();
			
			//Convert hash value from bytes to hex using StringBuffer instead of StringBuilder for security
			StringBuffer bytesToHex = new StringBuffer();
			for (int i =0;i < digest.length;i++) {
				bytesToHex.append(Integer.toHexString(0xFF & digest[i]));
			}
			return "CheckSum Value: " + bytesToHex.toString();
		} catch (NoSuchAlgorithmException ex) {throw new RuntimeException(ex);}
		
	}
	//Map the web request to the @RestController
	@RequestMapping("/hash")
	public String myHash() {
		//String to be encrypted with the SHA-256 algorithm
		String data = " Sarah Jodrey has created this CheckSum :]";
		
		return "<p>data: " + data + "<p>Cipher Algorithm SHA-256 : " + hashFunction(data);
	}
}